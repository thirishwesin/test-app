export const ModalConstant = {
    CLICK_EVENT: {
        DELETE_CLICK: 'Delete click'
    },
    ACTION: {
        DELETE: 'Delete', 
    },
    QUESTIONS: {

        DELETE_USER: 'Are you sure to delete user?',
       
    }
}