
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal,ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { cloneDeep } from 'lodash';
import { RegisterService } from '../register.service';
import { initUser, User } from '../user';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  closeResult = '';
  userList: User[] = [];
  user: User = cloneDeep(initUser);
  constructor(public service:RegisterService, private router : Router,private modalService: NgbModal) { 
  
  }
  

  ngOnInit(): void {

    this.service.getUser().subscribe((userList: User[]) => {

    this.userList = userList;
    console.log('user list in user com..',this.userList)
    });
    
 
  }

  editUser(id:any){
   
      this.router.navigate(['register', id]).then(isRouted => {
        console.log("Is successfully routed => ", isRouted);
      }).catch(error => {
        console.error("Getting error => ", error);
      });
  }

  open(content:any, id:any) {  
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {  
      this.closeResult = `Closed with: ${result}`;  
      if (result === 'yes') {  
        this.deleteUser(id);
      } 
    }, (reason) => {  
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;  
    });  
  }  

  edit(reason:any, id:any) {  
    this.modalService.open(reason, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {  
      this.closeResult = `Closed with: ${result}`;  
      if (result === 'yes') {  
        this.editUser(id);
      } 
    }, (reason) => {  
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;  
    });  
  }  

  
  private getDismissReason(reason: any): string { 
    if (reason === ModalDismissReasons.ESC) {  
      return 'by pressing ESC';  
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {  
      return 'by clicking on a backdrop';  
    } else {  
      return `with: ${reason}`;  
    }  
  }  

  deleteUser(id:any){
    this.service.removeFromList(id as string)
      .subscribe(
        () => this.router.navigate(['/user'])
      );
  }

}

