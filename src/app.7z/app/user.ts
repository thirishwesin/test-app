export interface User {
  id: string;
  name: string;
  phno: string;
  email: string;
  nrc: string;
}

export const initUser: User = {
  id: "0",
  name: "",
  phno: "",
  email: "",
  nrc: "",
}




